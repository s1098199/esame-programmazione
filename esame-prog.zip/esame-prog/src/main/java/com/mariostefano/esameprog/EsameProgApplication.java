package com.mariostefano.esameprog;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EsameProgApplication {

	public static void main(String[] args) {
		SpringApplication.run(EsameProgApplication.class, args);
	}

}
