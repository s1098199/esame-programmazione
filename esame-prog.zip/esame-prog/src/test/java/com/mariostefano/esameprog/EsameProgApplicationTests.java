package com.mariostefano.esameprog;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EsameProgApplicationTests {

	@Test
	void contextLoads() {
	}

}
